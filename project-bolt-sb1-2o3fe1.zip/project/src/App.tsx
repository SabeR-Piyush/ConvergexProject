import React from 'react';
import { Category, Parameter } from './types';
import { CategorySelector } from './components/CategorySelector';
import { PreferenceSelector } from './components/PreferenceSelector';
import { ProductComparison } from './components/ProductComparison';
import { categoryParameters } from './data/parameters';
import { products } from './data/products';
import { ThemeToggle } from './components/ThemeToggle';

type Step = 'category' | 'preferences' | 'comparison';

function App() {
  const [step, setStep] = React.useState<Step>('category');
  const [selectedCategory, setSelectedCategory] = React.useState<Category | null>(null);
  const [preferences, setPreferences] = React.useState<Parameter[]>([]);
  const [isDarkMode, setIsDarkMode] = React.useState(false);

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category);
    setStep('preferences');
  };

  const handlePreferencesSet = (prefs: Parameter[]) => {
    setPreferences(prefs);
    setStep('comparison');
  };

  const handleBack = () => {
    if (step === 'preferences') {
      setStep('category');
      setSelectedCategory(null);
    } else if (step === 'comparison') {
      setStep('preferences');
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'
    }`}>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className={`text-3xl font-bold ${
            isDarkMode ? 'text-white' : 'text-gray-900'
          }`}>
            Product Comparison Tool
          </h1>
          <ThemeToggle isDarkMode={isDarkMode} onToggle={() => setIsDarkMode(!isDarkMode)} />
        </div>

        {step === 'category' && (
          <CategorySelector onSelect={handleCategorySelect} isDarkMode={isDarkMode} />
        )}

        {step === 'preferences' && selectedCategory && (
          <PreferenceSelector
            parameters={categoryParameters[selectedCategory]}
            onPreferencesSet={handlePreferencesSet}
            onBack={handleBack}
            isDarkMode={isDarkMode}
          />
        )}

        {step === 'comparison' && selectedCategory && (
          <ProductComparison
            products={products.filter(p => p.category === selectedCategory)}
            preferences={preferences}
            onBack={handleBack}
            isDarkMode={isDarkMode}
          />
        )}
      </div>
    </div>
  );
}

export default App;