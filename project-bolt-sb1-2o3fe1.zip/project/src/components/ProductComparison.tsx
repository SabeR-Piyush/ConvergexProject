import React from 'react';
import { Product, Parameter } from '../types';

interface ProductComparisonProps {
  products: Product[];
  preferences: Parameter[];
  onBack: () => void;
  isDarkMode: boolean;
}

export function ProductComparison({
  products,
  preferences,
  onBack,
  isDarkMode
}: ProductComparisonProps) {
  const calculateAIScore = (product: Product): number => {
    let score = 0;
    let maxScore = 0;

    preferences.forEach((pref) => {
      const weight = pref.priority === 'High' ? 3 : pref.priority === 'Medium' ? 2 : 1;
      maxScore += weight * 10;
      
      // Enhanced scoring based on specifications
      const specKey = pref.name.toLowerCase().replace(/\s+/g, '');
      if (product.specifications[specKey]) {
        score += weight * 10;
      }
    });

    return (score / maxScore) * 100;
  };

  const sortedProducts = React.useMemo(() => {
    return [...products].sort((a, b) => {
      const scoreA = calculateAIScore(a);
      const scoreB = calculateAIScore(b);
      return scoreB - scoreA;
    });
  }, [products, preferences]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className={`text-2xl font-bold ${
          isDarkMode ? 'text-white' : 'text-gray-900'
        }`}>Product Comparison Results</h2>
        <button
          onClick={onBack}
          className={`px-4 py-2 rounded-lg transition-colors ${
            isDarkMode
              ? 'text-gray-300 hover:text-white hover:bg-gray-800'
              : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          ← Back
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedProducts.map((product, index) => {
          const aiScore = calculateAIScore(product);
          
          return (
            <div
              key={product.id}
              className={`rounded-lg shadow-lg overflow-hidden ${
                isDarkMode ? 'bg-gray-800' : 'bg-white'
              } ${index === 0 ? 'ring-2 ring-blue-500' : ''}`}
            >
              {index === 0 && (
                <div className="bg-blue-600 text-white text-center py-2 font-semibold">
                  Best Match for Your Preferences
                </div>
              )}
              
              <div className="p-4">
                <h3 className={`text-xl font-bold ${
                  isDarkMode ? 'text-white' : 'text-gray-900'
                }`}>{product.name}</h3>
                <p className="text-2xl font-bold text-blue-500 mt-2">
                  ₹{product.price.toLocaleString('en-IN')}
                </p>
                
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      AI Score
                    </span>
                    <span className={`font-bold ${
                      isDarkMode ? 'text-white' : 'text-gray-900'
                    }`}>{Math.round(aiScore)}%</span>
                  </div>
                  <div className={`w-full ${
                    isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
                  } rounded-full h-2`}>
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${aiScore}%` }}
                    />
                  </div>
                </div>

                <div className="mt-4 space-y-2">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className={`capitalize ${
                        isDarkMode ? 'text-gray-400' : 'text-gray-600'
                      }`}>{key}</span>
                      <span className={`font-medium ${
                        isDarkMode ? 'text-white' : 'text-gray-900'
                      }`}>{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}