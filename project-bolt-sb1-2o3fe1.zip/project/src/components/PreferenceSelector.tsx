import React from 'react';
import { Parameter, Priority } from '../types';

interface PreferenceSelectorProps {
  parameters: string[];
  onPreferencesSet: (preferences: Parameter[]) => void;
  onBack: () => void;
  isDarkMode: boolean;
}

export function PreferenceSelector({
  parameters,
  onPreferencesSet,
  onBack,
  isDarkMode
}: PreferenceSelectorProps) {
  const [preferences, setPreferences] = React.useState<Parameter[]>(
    parameters.map((param) => ({ name: param, priority: 'Medium' }))
  );

  const handlePriorityChange = (paramName: string, priority: Priority) => {
    setPreferences((prev) =>
      prev.map((p) => (p.name === paramName ? { ...p, priority } : p))
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className={`text-2xl font-bold ${
          isDarkMode ? 'text-white' : 'text-gray-900'
        }`}>Set Your Preferences</h2>
        <button
          onClick={onBack}
          className={`px-4 py-2 rounded-lg transition-colors ${
            isDarkMode
              ? 'text-gray-300 hover:text-white hover:bg-gray-800'
              : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          ← Back
        </button>
      </div>
      
      <div className="space-y-4">
        {parameters.map((param) => (
          <div
            key={param}
            className={`p-4 rounded-lg shadow ${
              isDarkMode ? 'bg-gray-800' : 'bg-white'
            }`}
          >
            <label className={`text-lg font-medium ${
              isDarkMode ? 'text-white' : 'text-gray-900'
            }`}>{param}</label>
            <div className="mt-2 flex gap-4">
              {(['High', 'Medium', 'Low'] as Priority[]).map((priority) => (
                <label key={priority} className="flex items-center">
                  <input
                    type="radio"
                    name={param}
                    checked={preferences.find((p) => p.name === param)?.priority === priority}
                    onChange={() => handlePriorityChange(param, priority)}
                    className="mr-2"
                  />
                  <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                    {priority}
                  </span>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={() => onPreferencesSet(preferences)}
        className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        Compare Products
      </button>
    </div>
  );
}