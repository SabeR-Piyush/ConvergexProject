import React from 'react';
import { Category } from '../types';
import { categoryParameters } from '../data/parameters';

interface CategorySelectorProps {
  onSelect: (category: Category) => void;
  isDarkMode: boolean;
}

export function CategorySelector({ onSelect, isDarkMode }: CategorySelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {(Object.keys(categoryParameters) as Category[]).map((category) => (
        <button
          key={category}
          onClick={() => onSelect(category)}
          className={`p-4 rounded-lg shadow-md hover:shadow-lg transition-all ${
            isDarkMode
              ? 'bg-gray-800 hover:bg-gray-700'
              : 'bg-white hover:bg-gray-50'
          }`}
        >
          <h3 className={`text-lg font-semibold ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>{category}</h3>
          <p className={`text-sm mt-2 ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`}>
            {categoryParameters[category].length} parameters
          </p>
        </button>
      ))}
    </div>
  );
}