import { Category } from '../types';

export const categoryParameters: Record<Category, string[]> = {
  Smartphones: ['Camera Quality', 'Display', 'Battery Life', 'Processor', 'Storage'],
  Laptops: ['Processor Brand', 'Processor Generation', 'Processor Speed', 'RAM', 'Storage', 'Battery Life', 'Display Quality', 'Build'],
  Tablets: ['Display Size', 'Processor', 'Battery Life', 'Storage', 'Camera Quality'],
  Smartwatches: ['Display', 'Battery Life', 'Health Tracking Features', 'Water Resistance', 'Connectivity'],
  Earphones: ['Sound Quality', 'Battery Life', 'Comfort', 'Noise Cancellation'],
  Cameras: ['Sensor Size', 'Lens Compatibility', 'Battery Life', 'Megapixels'],
  Televisions: ['Display Quality', 'Screen Size', 'Sound Output', 'Smart Features', 'Connectivity']
};