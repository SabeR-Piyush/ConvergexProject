import { Product } from '../types';

export const products: Product[] = [
  // Smartphones
  {
    id: 'smartphone-1',
    name: 'Galaxy S23 Ultra',
    category: 'Smartphones',
    price: 124999,
    specifications: {
      processor: 'Snapdragon 8 Gen 2',
      camera: '200 MP camera',
      display: 'AMOLED 2K display',
      battery: '5000 mAh'
    }
  },
  {
    id: 'smartphone-2',
    name: 'iPhone 15 Pro Max',
    category: 'Smartphones',
    price: 159999,
    specifications: {
      processor: 'A17 Bionic',
      camera: '48 MP camera',
      display: 'Super Retina XDR',
      battery: '4323 mAh'
    }
  },
  {
    id: 'smartphone-3',
    name: 'OnePlus 11',
    category: 'Smartphones',
    price: 61999,
    specifications: {
      processor: 'Snapdragon 8 Gen 2',
      camera: '50 MP camera',
      display: 'AMOLED display',
      battery: '5000 mAh'
    }
  },

  // Laptops
  {
    id: 'laptop-1',
    name: 'MacBook Pro M2',
    category: 'Laptops',
    price: 129999,
    specifications: {
      processor: 'Apple M2',
      ram: '16 GB',
      storage: '512 GB SSD',
      display: '14-inch Retina display'
    }
  },
  {
    id: 'laptop-2',
    name: 'Dell XPS 13',
    category: 'Laptops',
    price: 99999,
    specifications: {
      processor: 'Intel i7-13th Gen',
      ram: '16 GB',
      storage: '512 GB SSD',
      display: 'InfinityEdge 13.3-inch display'
    }
  },
  {
    id: 'laptop-3',
    name: 'HP Spectre x360',
    category: 'Laptops',
    price: 119999,
    specifications: {
      processor: 'Intel i7-12th Gen',
      ram: '16 GB',
      storage: '1 TB SSD',
      display: 'Touchscreen OLED display'
    }
  },

  // Smartwatches
  {
    id: 'watch-1',
    name: 'Apple Watch Ultra',
    category: 'Smartwatches',
    price: 89999,
    specifications: {
      battery: '36-hour battery',
      features: 'dual-frequency GPS',
      display: 'Always-on Retina display',
      design: 'rugged design'
    }
  },
  {
    id: 'watch-2',
    name: 'Galaxy Watch 6',
    category: 'Smartwatches',
    price: 36999,
    specifications: {
      processor: 'Exynos W930',
      display: 'Sapphire crystal AMOLED',
      battery: '40-hour battery'
    }
  },
  {
    id: 'watch-3',
    name: 'Fitbit Sense 2',
    category: 'Smartwatches',
    price: 24999,
    specifications: {
      features: 'Health tracking',
      display: 'AMOLED display',
      battery: '6-day battery life',
      connectivity: 'GPS'
    }
  },

  // Earphones
  {
    id: 'earphone-1',
    name: 'Sony WF-1000XM4',
    category: 'Earphones',
    price: 19990,
    specifications: {
      features: 'Active noise cancellation',
      audio: 'LDAC support',
      battery: '8-hour battery'
    }
  },
  {
    id: 'earphone-2',
    name: 'Bose QuietComfort Earbuds II',
    category: 'Earphones',
    price: 22900,
    specifications: {
      features: 'Advanced ANC',
      audio: 'balanced sound',
      battery: '6-hour battery'
    }
  },
  {
    id: 'earphone-3',
    name: 'Jabra Elite 7 Pro',
    category: 'Earphones',
    price: 14999,
    specifications: {
      features: 'Multi-point connectivity',
      audio: 'ANC',
      battery: '9-hour battery'
    }
  },

  // Cameras
  {
    id: 'camera-1',
    name: 'Canon EOS R6 Mark II',
    category: 'Cameras',
    price: 243990,
    specifications: {
      sensor: '24.2 MP',
      video: '4K60 video',
      features: 'Dual Pixel AF'
    }
  },
  {
    id: 'camera-2',
    name: 'Sony Alpha A7 IV',
    category: 'Cameras',
    price: 219990,
    specifications: {
      sensor: '33 MP',
      video: '4K60 video',
      features: 'Real-time Eye AF'
    }
  },
  {
    id: 'camera-3',
    name: 'Nikon Z6 II',
    category: 'Cameras',
    price: 189990,
    specifications: {
      sensor: '24.5 MP',
      video: '4K UHD',
      processor: 'Dual Expeed 6 processors'
    }
  },

  // Televisions
  {
    id: 'tv-1',
    name: 'LG OLED C2',
    category: 'Televisions',
    price: 129999,
    specifications: {
      display: '55-inch OLED 4K',
      features: 'AI-enhanced visuals',
      audio: 'Dolby Atmos'
    }
  },
  {
    id: 'tv-2',
    name: 'Sony Bravia XR X90K',
    category: 'Televisions',
    price: 149999,
    specifications: {
      display: '65-inch Full Array LED',
      processor: 'XR processor',
      audio: 'Acoustic Surface Audio'
    }
  },
  {
    id: 'tv-3',
    name: 'Samsung QN90B Neo QLED',
    category: 'Televisions',
    price: 159999,
    specifications: {
      display: '55-inch QLED 4K',
      features: 'Quantum Matrix Tech',
      audio: 'Object Tracking Sound'
    }
  }
];