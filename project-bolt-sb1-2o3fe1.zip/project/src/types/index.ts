export type Priority = 'High' | 'Medium' | 'Low';

export type Category = 'Smartphones' | 'Laptops' | 'Tablets' | 'Smartwatches' | 'Earphones' | 'Cameras' | 'Televisions';

export type Parameter = {
  name: string;
  priority: Priority;
};

export type Product = {
  id: string;
  name: string;
  category: Category;
  price: number;
  specifications: Record<string, string | number>;
  aiScore?: number;
};